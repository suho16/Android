const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");
admin.initializeApp();

// 새 메시지가 생기면 상대방들에게 푸시 알림 전송
exports.notifyMessage = onDocumentCreated("chats/{chatId}/messages/{msgId}", async (event) => {
  const m = event.data.data();
  const db = admin.firestore();
  const chat = (await db.doc(`chats/${event.params.chatId}`).get()).data();
  const targets = chat.members.filter((u) => u !== m.senderId);
  const snaps = await Promise.all(targets.map((u) => db.doc(`users/${u}`).get()));
  const tokens = snaps.map((s) => s.get("fcmToken")).filter(Boolean);
  if (!tokens.length) return;
  await admin.messaging().sendEachForMulticast({
    tokens,
    notification: {
      title: chat.group ? `${chat.name} · ${m.senderName}` : m.senderName,
      body: m.text || "📷 사진",
    },
    data: { chatId: event.params.chatId },
  });
});
