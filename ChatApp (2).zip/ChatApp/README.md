# ChatApp (Android / Kotlin + Compose + Firebase)

기능: 이메일 로그인, 1:1 채팅, 그룹 채팅, 사진 전송, 푸시 알림

## 설정 순서
1. https://console.firebase.google.com 에서 프로젝트 생성
2. 프로젝트에 Android 앱 추가 → 패키지명 `com.example.chatapp`
   → `google-services.json` 다운로드 → `app/` 폴더에 넣기
3. Firebase 콘솔에서 활성화
   - Authentication → 이메일/비밀번호
   - Firestore Database 생성 (`firestore.rules` 내용 붙여넣기)
   - Storage 생성 (`storage.rules` 내용 붙여넣기)
4. Android Studio에서 이 폴더 열기 → Sync → 실행
5. 푸시 알림 (Cloud Functions, Blaze 요금제 필요)
   ```
   npm i -g firebase-tools
   firebase login
   firebase use --add
   firebase deploy --only functions
   ```
   푸시 없이 채팅만 쓰려면 이 단계는 건너뛰어도 됩니다.

## 테스트
에뮬레이터/폰 2대(또는 기기 1 + 에뮬 1)에 각각 다른 계정으로 가입하면 서로 목록에 보입니다.

## GitHub로 빌드하기 (Android Studio 없이)
1. `app/google-services.json`을 넣은 상태로 이 폴더 전체를 **비공개(private)** GitHub 저장소에 업로드
2. 저장소의 Actions 탭 → Build APK 실행이 끝나길 기다림 (약 5분)
3. 실행 결과 화면 아래 Artifacts의 `ChatApp-apk`를 내려받아 압축 해제 → `app-debug.apk`를 폰에 설치
