package com.suho.heartrate

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.ScrollView
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.ArrayDeque
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var previewHint: TextView
    private lateinit var bpmText: TextView
    private lateinit var statusText: TextView
    private lateinit var instructionText: TextView
    private lateinit var startButton: Button
    private lateinit var cameraExecutor: ExecutorService

    private var camera: Camera? = null
    private var measuring = false
    private val signal = ArrayDeque<Sample>()
    private var lastUiUpdate = 0L
    private var startedAt = 0L

    private data class Sample(val time: Long, val value: Double)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else statusText.text = "카메라 권한이 필요합니다."
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildUi()

        startButton.setOnClickListener {
            if (!measuring) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                    == PackageManager.PERMISSION_GRANTED
                ) startCamera() else permissionLauncher.launch(Manifest.permission.CAMERA)
            } else {
                stopMeasurement()
            }
        }
    }

    private fun buildUi() {
        val page = ScrollView(this).apply {
            setFillViewport(true)
            setBackgroundColor(Color.rgb(8, 14, 27))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(Color.rgb(8, 14, 27))
        }
        page.addView(root)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val mark = TextView(this).apply {
            text = "♥"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(226, 55, 91), 16)
        }
        header.addView(mark, LinearLayout.LayoutParams(dp(48), dp(48)))
        val brandTexts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        brandTexts.addView(label("PULSE", 18f, Color.WHITE, true))
        brandTexts.addView(label("카메라 심박수 측정", 12f, Color.rgb(151, 166, 188)))
        header.addView(brandTexts)
        root.addView(header, matchWrap())

        root.addView(label("오늘의 심박 리듬을 확인하세요", 19f, Color.WHITE, true).apply {
            setPadding(0, dp(28), 0, dp(14))
        }, matchWrap())

        val bpmCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(Color.rgb(21, 31, 49), 22)
        }
        bpmCard.addView(label("현재 심박수", 13f, Color.rgb(159, 176, 199), true), matchWrap())
        bpmText = TextView(this).apply {
            text = "--"
            textSize = 62f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(Color.rgb(255, 91, 119))
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, 0)
        }
        bpmCard.addView(bpmText, matchWrap())
        bpmCard.addView(label("BPM  ·  분당 심박수", 13f, Color.rgb(159, 176, 199)), matchWrap())
        statusText = label("측정을 시작해 주세요", 13f, Color.rgb(190, 220, 226), true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = rounded(Color.rgb(27, 54, 66), 30)
        }
        bpmCard.addView(statusText, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) })
        root.addView(bpmCard, matchWrap())

        val cameraHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(22), 0, dp(10))
        }
        cameraHeader.addView(label("카메라 센서", 15f, Color.WHITE, true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        cameraHeader.addView(label("후면 카메라 사용", 11f, Color.rgb(133, 153, 180)))
        root.addView(cameraHeader, matchWrap())

        val cameraFrame = FrameLayout(this).apply {
            background = rounded(Color.rgb(3, 7, 14), 20)
            clipToOutline = true
        }
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        cameraFrame.addView(previewView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ))
        previewHint = TextView(this).apply {
            text = "◎\n\n측정을 시작하면 카메라가 켜집니다"
            textSize = 14f
            gravity = Gravity.CENTER
            setLineSpacing(dp(3).toFloat(), 1f)
            setTextColor(Color.rgb(145, 164, 190))
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        cameraFrame.addView(previewHint, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ))
        root.addView(cameraFrame, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(230)
        ))

        instructionText = label(
            "손가락 끝을 후면 카메라와 플래시에 가볍게 대세요.\n측정 중에는 손가락을 세게 누르거나 움직이지 마세요.",
            12f, Color.rgb(155, 170, 192)
        ).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(14), dp(8), dp(16))
            setLineSpacing(dp(3).toFloat(), 1f)
        }
        root.addView(instructionText, matchWrap())

        startButton = Button(this).apply {
            text = "측정 시작"
            isAllCaps = false
            textSize = 16f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(226, 55, 91), 16)
            stateListAnimator = null
            minHeight = dp(54)
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        root.addView(startButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(56)
        ))
        root.addView(label(
            "참고용 측정 앱이며 의료 진단이나 응급 판단에 사용할 수 없습니다.",
            10f, Color.rgb(112, 128, 151)
        ).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(4))
        }, matchWrap())
        setContentView(page)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun label(textValue: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = textValue
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun startCamera() {
        statusText.text = "카메라 준비 중..."
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()

                analysis.setAnalyzer(cameraExecutor) { image ->
                    try {
                        if (measuring) {
                            val red = averageCenterRed(image)
                            if (red != null) processSample(red)
                        }
                    } finally {
                        image.close()
                    }
                }

                provider.unbindAll()
                camera = provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis
                )
                if (camera?.cameraInfo?.hasFlashUnit() == true) {
                    camera?.cameraControl?.enableTorch(true)
                }
                synchronized(signal) { signal.clear() }
                measuring = true
                startedAt = SystemClock.elapsedRealtime()
                runOnUiThread {
                    bpmText.text = "--"
                    statusText.text = "측정 중 · 손가락을 카메라에 대세요"
                    previewHint.visibility = View.GONE
                    startButton.text = "측정 중지"
                }
            } catch (e: Exception) {
                runOnUiThread { statusText.text = "카메라를 시작하지 못했습니다: ${e.message}" }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // YUV 프레임 중앙 영역의 R 성분을 근사해 PPG 신호로 사용합니다.
    private fun averageCenterRed(image: androidx.camera.core.ImageProxy): Double? {
        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]
        val width = image.width
        val height = image.height
        val yBuffer = yPlane.buffer
        val uBuffer = uPlane.buffer
        val vBuffer = vPlane.buffer
        val yRow = yPlane.rowStride
        val yPixel = yPlane.pixelStride
        val uRow = uPlane.rowStride
        val uPixel = uPlane.pixelStride
        val vRow = vPlane.rowStride
        val vPixel = vPlane.pixelStride

        val left = width * 2 / 5
        val right = width * 3 / 5
        val top = height * 2 / 5
        val bottom = height * 3 / 5
        var total = 0.0
        var count = 0

        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                val yIndex = y * yRow + x * yPixel
                val uvX = x / 2
                val uvY = y / 2
                val uIndex = uvY * uRow + uvX * uPixel
                val vIndex = uvY * vRow + uvX * vPixel
                val yy = (yBuffer.get(yIndex).toInt() and 0xff).toDouble()
                val vv = (vBuffer.get(vIndex).toInt() and 0xff).toDouble() - 128.0
                val red = yy + 1.402 * vv
                total += red
                count++
                x += 4
            }
            y += 4
        }
        return if (count > 0) total / count else null
    }

    private fun processSample(value: Double) {
        val now = SystemClock.elapsedRealtime()
        synchronized(signal) {
            signal.addLast(Sample(now, value))
            while (signal.isNotEmpty() && now - signal.first.time > 12_000L) {
                signal.removeFirst()
            }
            if (now - lastUiUpdate < 500L) return
            lastUiUpdate = now

            if (now - startedAt < 5_000L || signal.size < 40) {
                runOnUiThread { statusText.text = "신호 분석 중... 손가락을 가만히 유지하세요." }
                return
            }

            val samples = signal.toList()
            val recent = samples.filter { now - it.time <= 8_000L }
            if (recent.size < 30) return

            val values = recent.map { it.value }
            val minV = values.minOrNull() ?: return
            val maxV = values.maxOrNull() ?: return
            val range = maxV - minV
            if (range < 2.0) {
                runOnUiThread { statusText.text = "신호가 약합니다. 손가락 위치를 조정하세요." }
                return
            }

            val threshold = minV + range * 0.55
            val peaks = mutableListOf<Long>()
            for (i in 1 until recent.size - 1) {
                val prev = recent[i - 1]
                val cur = recent[i]
                val next = recent[i + 1]
                if (cur.value > prev.value && cur.value >= next.value &&
                    cur.value > threshold
                ) {
                    if (peaks.isEmpty() || cur.time - peaks.last() > 400L) {
                        peaks.add(cur.time)
                    } else if (cur.time - peaks.last() < 1_500L) {
                        // 가까운 후보 중 더 높은 봉우리를 선택
                        val lastIndex = recent.indexOfFirst { it.time == peaks.last() }
                        if (lastIndex >= 0 && cur.value > recent[lastIndex].value) {
                            peaks[peaks.lastIndex] = cur.time
                        }
                    }
                }
            }

            if (peaks.size >= 3) {
                val intervals = peaks.zipWithNext { a, b -> b - a }
                    .filter { it in 400L..1_500L }
                if (intervals.size >= 2) {
                    val sorted = intervals.sorted()
                    val median = sorted[sorted.size / 2].toDouble()
                    val bpm = (60_000.0 / median).toInt()
                    if (bpm in 40..180) {
                        runOnUiThread {
                            bpmText.text = bpm.toString()
                            statusText.text = "측정 중 · 값은 참고용 추정치입니다."
                        }
                        return
                    }
                }
            }
            runOnUiThread { statusText.text = "맥박 신호를 찾는 중... 손가락을 가만히 대세요." }
        }
    }

    private fun stopMeasurement() {
        measuring = false
        camera?.cameraControl?.enableTorch(false)
        camera = null
        synchronized(signal) { signal.clear() }
        bpmText.text = "--"
        statusText.text = "측정이 중지되었습니다."
        previewHint.visibility = View.VISIBLE
        startButton.text = "측정 시작"
    }

    override fun onDestroy() {
        measuring = false
        camera?.cameraControl?.enableTorch(false)
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
